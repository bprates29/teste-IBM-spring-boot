package br.com.test.ibm.ibmtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IbmtestApplication {

	public static void main(String[] args) {
		SpringApplication.run(IbmtestApplication.class, args);
	}

}
