package br.com.test.ibm.ibmtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IbmtestApplicationTests {

	@Test
	void contextLoads() {
	}

}
